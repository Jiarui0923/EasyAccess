"""
DocFlow

This module imports various components used to build markdown documentation in the DocFlow project.
The components include different document types such as text, code, images, tables, and badges, 
as well as utilities like timestamps, expanders, and catalogs. The imported classes and functions 
are used to create and manage different types of markdown documentation structures.

Author: Jiarui Li
Email: jli78@tulane.edu
University: Tulane University, Computer Science Department
"""

from .document import Document
from .plaintext import Title, Text
from .code import Code
from .badge import Badge, IdenticalBadge
from .sequence import Sequence
from .table import Table
from .image import EmbeddedImage
from .stamp import DateTimeStamp, UUIDStamp
from .expander import Expander
from .magic import Magic
from .catalog import Catalog
