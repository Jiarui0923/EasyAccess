"""
Module: Expander

This module defines the `Expander` class, which represents a collapsible section in a markdown document.
It allows the user to create a section with a title, where the content can be revealed or hidden by
clicking the title. The content and title can be either plain text or other `Document` objects.

Author: Jiarui Li
Email: jli78@tulane.edu
University: Tulane University, Computer Science Department
"""

from .document import Document


class Expander(Document):
    """
    Class to represent a collapsible section in a markdown document.

    This section can have a title, content, and an open state that determines whether 
    the section is initially expanded or collapsed.

    Attributes:
        content (str or Document): The content to be displayed within the section.
        title (str or Document): The title of the collapsible section.
        open (bool): Whether the section is initially open (expanded) or closed (collapsed).

    Methods:
        __init__(content, title='', open=False): Initializes the Expander with content, title, and open state.
        markdown: Property that returns the markdown representation of the collapsible section.
    """
    
    def __init__(self, content, title='', open=False):
        """
        Initializes the Expander instance. It accepts content, title, and an optional open state.
        
        Args:
            content (str or Document): The content to be displayed within the section.
            title (str or Document, optional): The title of the collapsible section. Defaults to an empty string.
            open (bool, optional): Whether the section is initially open (expanded). Defaults to False.
        """
        self.content = content
        self.title = title
        self.open = open

    @property    
    def markdown(self):
        """
        Returns the markdown representation of the collapsible section.

        The section is wrapped in a <details> HTML tag, and the title is inside a <summary> tag. 
        The content can be plain text or HTML, depending on whether it is a Document object or a string.

        Returns:
            str: A markdown string containing the HTML for the collapsible section.
        """
        if isinstance(self.content, Document):
            _content = self.content.html
        else:
            _content = str(self.content)

        if isinstance(self.title, Document):
            _title = self.title.html
        else:
            _title = str(self.title)

        open_tag = ' open' if self.open else ''
        return f'<details{open_tag}>\n<summary>{_title}</summary>\n{_content}\n</details>\n'
