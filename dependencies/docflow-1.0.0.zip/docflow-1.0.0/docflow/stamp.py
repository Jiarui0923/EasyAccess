"""
Module: docflow_stamps_module

This module provides classes for generating dynamic content stamps for documentation.
It includes DateTimeStamp for creating timestamp strings and UUIDStamp for generating
unique identifiers. Both classes extend the Document base class and generate output
in Markdown format.

Author: Jiarui Li
Email: jli78@tulane.edu
Institution: Computer Science Department, Tulane University
"""

from datetime import datetime
from uuid import uuid4
from .document import Document

class DateTimeStamp(Document):
    """
    A class to generate a timestamp for documentation purposes.

    This class extends the Document class and produces a formatted timestamp
    string, optionally with additional text, in Markdown format.

    Attributes:
    -----------
    _timefmt : str
        The format string for the timestamp.
    _text : str or None
        Additional text to append to the timestamp.
    """

    def __init__(self, timefmt='%d-%m-%Y %H:%M:%S %Z', text=None):
        """
        Initialize the DateTimeStamp with a specific format and optional text.

        Parameters:
        -----------
        timefmt : str, optional
            A format string for datetime.strftime (default is '%d-%m-%Y %H:%M:%S %Z').
        text : str, optional
            Additional text to append to the timestamp (default is None).
        """
        self._timefmt = timefmt
        self._text = text

    @property
    def markdown(self):
        """
        Generate a Markdown representation of the timestamp.

        Returns:
        --------
        str
            A string containing the formatted timestamp in Markdown format.
        """
        _time = datetime.now().astimezone().strftime(self._timefmt)
        if self._text is None:
            return f"`{_time}`  \n"
        return f"`{_time} {self._text}`  \n"

class UUIDStamp(Document):
    """
    A class to generate a UUID for documentation purposes.

    This class extends the Document class and produces a UUID string, optionally
    with additional text, in Markdown format.

    Attributes:
    -----------
    _text : str or None
        Additional text to append to the UUID.
    """

    def __init__(self, text=None):
        """
        Initialize the UUIDStamp with optional text.

        Parameters:
        -----------
        text : str, optional
            Additional text to append to the UUID (default is None).
        """
        self._text = text

    @property
    def markdown(self):
        """
        Generate a Markdown representation of the UUID.

        Returns:
        --------
        str
            A string containing the UUID in Markdown format.
        """
        _uuid = str(uuid4()).upper()
        if self._text is None:
            return f"`{_uuid}`  \n"
        return f"`{_uuid} {self._text}`  \n"
