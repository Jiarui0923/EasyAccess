"""
Module: Badge

This module defines the `Badge` and `IdenticalBadge` classes, which represent badges to be embedded
into markdown documents. Badges are often used to display status or information, such as build status,
license type, or version number, and are generated using the Shields.io service.

Author: Jiarui Li
Email: jli78@tulane.edu
University: Tulane University, Computer Science Department
"""

from .document import Document


class Badge(Document):
    """
    Class to represent a customizable badge.

    This class generates a badge that can be embedded in a markdown document. The badge is created
    using the Shields.io service, and the appearance is controlled by the badge's head, tail, and color.

    Attributes:
        _badge (str): The markdown string representing the badge.

    Methods:
        __init__(head='', tail='', color='2ea44f'): Initializes the Badge with optional text and color.
        markdown: Property that returns the markdown representation of the badge.
    """
    
    def __init__(self, head='', tail='', color='2ea44f'):
        """
        Initializes the Badge instance with a head, tail, and color.

        The head and tail are used as the label for the badge, and the color controls the badge's appearance.

        Args:
            head (str, optional): The text for the left side of the badge. Defaults to an empty string.
            tail (str, optional): The text for the right side of the badge. Defaults to an empty string.
            color (str, optional): The color of the badge in hexadecimal format. Defaults to '2ea44f'.
        """
        self._badge = f'![{head}-{tail}](https://img.shields.io/badge/{head}-{tail}-{color})'
    
    @property  
    def markdown(self):
        """
        Returns the markdown representation of the badge.

        Returns:
            str: The markdown string representing the badge.
        """
        return f'{self._badge}  \n\n'


class IdenticalBadge(Document):
    """
    Class to represent a fixed badge with a predefined label and color.

    This class generates a badge with the label 'DocFlow-AutoDoc' and the color '2ea44f'. 
    It can be used when a static badge is required.

    Attributes:
        _badge (str): The markdown string representing the predefined badge.

    Methods:
        __init__(): Initializes the IdenticalBadge with fixed text and color.
        markdown: Property that returns the markdown representation of the predefined badge.
    """
    
    def __init__(self):
        """
        Initializes the IdenticalBadge instance with the fixed label 'DocFlow-AutoDoc' and color '2ea44f'.
        """
        self._badge = '![DocFlow-AutoDoc](https://img.shields.io/badge/DocFlow-AutoDoc-2ea44f)'
    
    @property  
    def markdown(self):
        """
        Returns the markdown representation of the predefined badge.

        Returns:
            str: The markdown string representing the predefined badge.
        """
        return f'{self._badge}  \n\n'
