"""
Module: EmbeddedImage

This module defines the `EmbeddedImage` class, which is used to embed images into markdown documents. 
It supports two types of image input: a matplotlib figure or an image file. The images are encoded in 
base64 format and can be directly embedded into the markdown.

Author: Jiarui Li
Email: jli78@tulane.edu
University: Tulane University, Computer Science Department
"""

import base64
import io
import os
import matplotlib
from .document import Document


class EmbeddedImage(Document):
    """
    Class to represent an image embedded into a markdown document.

    The image can be passed as either a matplotlib figure or a file path. The image is 
    encoded in base64 and returned as a markdown-friendly HTML image tag.

    Attributes:
        _image_base64 (str): The base64 encoded image string wrapped in an HTML <img> tag.

    Methods:
        __init__(image): Initializes the EmbeddedImage instance from a matplotlib figure or an image file.
        markdown: Property that returns the markdown representation of the embedded image.
    """
    
    def __init__(self, image):
        """
        Initializes the EmbeddedImage instance. If the input is a matplotlib figure, it is saved as a 
        JPG image and then encoded in base64. If the input is a file path, the image is read from the 
        file and encoded in base64.

        Args:
            image (matplotlib.figure.Figure or str): The input image, either a matplotlib figure or 
                                                     the path to an image file.

        Raises:
            TypeError: If the input is neither a matplotlib figure nor a valid file path.
        """
        if isinstance(image, matplotlib.figure.Figure):
            img_stream = io.BytesIO()
            image.savefig(img_stream, format='jpg', bbox_inches='tight')
            img_stream.seek(0)
            img_base64 = base64.b64encode(img_stream.read()).decode()
            self._image_base64 = f'<img src="data:image/jpg;base64,{img_base64}">'
            image.clear()
            matplotlib.pyplot.close(image)
        elif os.path.isfile(image):
            with open(image, 'rb') as f:
                img_stream = io.BytesIO(f.read())
                img_stream.seek(0)
                img_base64 = base64.b64encode(img_stream.read()).decode()
                self._image_base64 = f'<img src="data:image/jpg;base64,{img_base64}">'
        else:
            raise TypeError("Input must be a matplotlib figure or a valid image file path.")

    @property
    def markdown(self):
        """
        Returns the markdown representation of the embedded image.

        Returns:
            str: A markdown string containing the base64 encoded image embedded in an HTML <img> tag.
        """
        return f'{self._image_base64}   \n\n'
