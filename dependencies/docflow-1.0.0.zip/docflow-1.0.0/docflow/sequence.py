"""
Module: docflow_sequence_module

This module provides the Sequence class for rendering lists or dictionaries
in Markdown format. The Sequence class extends the Document base class 
and supports optional indexing of items.

Author: Jiarui Li
Email: jli78@tulane.edu
Institution: Computer Science Department, Tulane University
"""

from .document import Document

class Sequence(Document):
    """
    A class to render sequences (lists or dictionaries) in Markdown format.

    This class extends the Document base class and supports rendering of
    sequences with optional numeric indexing.

    Attributes:
    -----------
    _seq : list or dict
        The sequence to be rendered in Markdown.
    _num_index : bool
        Whether to include numeric indexing for items (default is False).
    """

    def __init__(self, seq, num_index=False):
        """
        Initialize the Sequence with a sequence and optional indexing.

        Parameters:
        -----------
        seq : list or dict
            The sequence to be rendered in Markdown format.
        num_index : bool, optional
            Whether to include numeric indexing for items (default is False).
        """
        self._seq = seq
        self._num_index = num_index

    @property
    def markdown(self):
        """
        Generate a Markdown representation of the sequence.

        If the sequence is a list, it renders the items as a bulleted or
        numbered list. If the sequence is a dictionary, it renders the
        key-value pairs with bold keys.

        Returns:
        --------
        str
            A string containing the sequence rendered in Markdown format.

        Raises:
        -------
        TypeError
            If the sequence is not a list or dictionary.
        """
        if isinstance(self._seq, list):
            items = [
                f"{i.markdown}" if isinstance(i, Document) else f"{i}"
                for i in self._seq
            ]
        elif isinstance(self._seq, dict):
            items = [
                f"**{i}**: {v.markdown}" if isinstance(v, Document) else f"**{i}**: {v}"
                for i, v in self._seq.items()
            ]
        else:
            raise TypeError("Sequence must be a list or dictionary.")

        if self._num_index:
            return "".join([f"{index + 1}. {item}  \n" for index, item in enumerate(items)])
        return "".join([f"- {item}  \n" for item in items])
