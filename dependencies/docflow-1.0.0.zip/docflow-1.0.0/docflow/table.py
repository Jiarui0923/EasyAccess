"""
Module: docflow_table_module

This module provides the Table class for managing and converting pandas DataFrames
into Markdown format for documentation purposes. The Table class inherits from the
Document base class and provides a convenient interface for generating Markdown
tables.

Author: Jiarui Li
Email: jli78@tulane.edu
Institution: Computer Science Department, Tulane University
"""

import pandas as pd
from .document import Document

class Table(Document):
    """
    A class to represent a table for documentation purposes.

    This class extends the Document class and provides functionality to convert
    a pandas DataFrame into a Markdown table representation.

    Attributes:
    -----------
    _df : pd.DataFrame
        The pandas DataFrame to be represented as a Markdown table.
    """

    def __init__(self, df):
        """
        Initialize the Table with a pandas DataFrame.

        Parameters:
        -----------
        df : pd.DataFrame
            The DataFrame to be converted into Markdown format.

        Raises:
        -------
        TypeError
            If the provided df is not an instance of pandas DataFrame.
        """
        if not isinstance(df, pd.DataFrame):
            raise TypeError("Input must be a pandas DataFrame.")
        self._df = df

    @property
    def markdown(self):
        """
        Generate a Markdown representation of the DataFrame.

        Returns:
        --------
        str
            A string containing the Markdown table representation of the DataFrame.
        """
        return f"{self._df.to_markdown()}  \n\n"
