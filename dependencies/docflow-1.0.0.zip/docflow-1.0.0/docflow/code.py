"""
Module: Code

This module defines the `Code` class, which represents a code block in a markdown document.
It supports rendering code from a function object or a string and can generate both markdown and HTML representations of the code block.

Author: Jiarui Li
Email: jli78@tulane.edu
University: Tulane University, Computer Science Department
"""

import markdown
import inspect
from .document import Document


class Code(Document):
    """
    Class to represent a code block in a markdown document.

    The class can accept either a function or a string as input. If a function is provided, its source code
    is extracted and used as the code content. The language of the code can be specified, and both markdown 
    and HTML representations of the code block are supported.

    Attributes:
        _obj (str): The code content (either the source code of a function or a provided string).
        _lang (str): The language in which the code is written (e.g., 'python').

    Methods:
        __init__(obj, lang=''): Initializes the Code instance with a function or string as the code content.
        markdown: Property that returns the markdown representation of the code block.
        html: Property that returns the HTML representation of the code block.
    """
    
    def __init__(self, obj, lang=''):
        """
        Initializes the Code instance. If a function is provided, its source code is extracted. 
        If a string is provided, it is used as the code content.

        Args:
            obj (function or str): The code content, either a function object or a string.
            lang (str, optional): The programming language of the code (default is an empty string).

        Raises:
            TypeError: If the input is neither a function nor a string.
        """
        if inspect.isfunction(obj):
            self._lang = 'python'
            self._obj = inspect.getsource(obj)
        elif isinstance(obj, str):
            self._lang = lang
            self._obj = obj
        else:
            raise TypeError("Input must be a function or a string.")

    @property
    def markdown(self):
        """
        Returns the markdown representation of the code block.

        The code is wrapped in triple backticks (```) with the specified language.

        Returns:
            str: A markdown string containing the code block.
        """
        return f'```{self._lang}\n{self._obj}\n```\n'

    @property
    def html(self):
        """
        Returns the HTML representation of the code block.

        The markdown representation is converted to HTML using the `markdown` module with the fenced code extension.

        Returns:
            str: The HTML representation of the code block.
        """
        return markdown.markdown(self.markdown, extensions=['fenced_code'])
