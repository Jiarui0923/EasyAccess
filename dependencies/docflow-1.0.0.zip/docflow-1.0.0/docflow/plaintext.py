"""
Module: docflow_title_text_module

This module provides the Title and Text classes for rendering titles and plain text 
in Markdown format. Both classes extend the Document base class.

Author: Jiarui Li
Email: jli78@tulane.edu
Institution: Computer Science Department, Tulane University
"""

from .document import Document

class Title(Document):
    """
    A class to render titles in Markdown format.

    This class extends the Document base class and supports rendering titles
    with configurable levels (from 1 to 5).

    Attributes:
    -----------
    _context : str
        The text content of the title.
    _level : int
        The level of the title, corresponding to the number of '#' symbols.
    """

    def __init__(self, context='', level=1):
        """
        Initialize the Title with content and level.

        Parameters:
        -----------
        context : str, optional
            The text content of the title (default is an empty string).
        level : int, optional
            The level of the title, from 1 (largest) to 5 (smallest, default is 1).

        Raises:
        -------
        ValueError
            If the level is not between 1 and 5.
        """
        if level < 1 or level > 5:
            raise ValueError(f"Title level must be between 1 and 5. {level} is not valid.")
        self._level = level
        self._context = context

    @property
    def markdown(self):
        """
        Generate a Markdown representation of the title.

        Returns:
        --------
        str
            A string containing the title rendered in Markdown format.
        """
        return f'{"#" * self._level} {self._context}  \n'


class Text(Document):
    """
    A class to render plain text in Markdown format.

    This class extends the Document base class.

    Attributes:
    -----------
    _text : str
        The plain text content.
    """

    def __init__(self, text):
        """
        Initialize the Text with content.

        Parameters:
        -----------
        text : str
            The plain text content.
        """
        self._text = text

    @property
    def markdown(self):
        """
        Generate a Markdown representation of the text.

        Returns:
        --------
        str
            A string containing the text rendered in Markdown format.
        """
        return f"{self._text}  \n"
