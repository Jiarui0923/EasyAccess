# <img src="./imgs/icon.png" width="36pt"> DocFlow
**`LAST UPDATE: 4/25/2024`**  
**`UPDATE BY: Jiarui LI`**  

## Introduction
This module imports various components used to build markdown documentation in the DocFlow project.
The components include different document types such as text, code, images, tables, and badges, 
as well as utilities like timestamps, expanders, and catalogs. The imported classes and functions 
are used to create and manage different types of markdown documentation structures.

This package is maintained by Jiarui LI. If there is any bug and question, please feel free to send Email to jli78@tulane.edu or post an issue.

## Requirements
|Package   |Version |Require |
|:---------|:------:|:-------|
|pandas    |`2.0.3` |`MUST`  |
|matplotlib|`3.7.3` |`MUST`  |
|markdown  |`3.4.1` |`MUST`  |
|tabulate  |`0.9.0` |`MUST`  |

Use the command below to install:
```bash
pip install pandas==2.0.3 matplotlib==3.7.3 markdown==3.0.0 tabulate==0.9.0
```
Or use the `requirements.txt`:
```bash
pip install -r requirements.txt
```

## Documentation
#### Initialize Document
```python
import docflow
doc = docflow.Document()
```

#### Save Document
```python
import docflow
doc = docflow.Document()
doc.save('./README.md')
```
or save as HTML
```python
import docflow
doc = docflow.Document()
doc.save('./README.html', format='html')
```

### Build Document Sequencially
```python
import docflow
docflow.Document(
    docflow.Title('Example Document', level=3),
    docflow.DateTimeStamp(),
    docflow.IdenticalBadge(),
    docflow.Text('This is an example.')
)
```
OUTPUT:  
> ### Example Document  
> `25-04-2024 16:18:14 Central Daylight Time`  
> ![DocFlow-AutoDoc](https://img.shields.io/badge/DocFlow-AutoDoc-2ea44f)  
> This is an example.  

#### Magic Method
```python
doc.add(
    docflow.Magic(anycontent)
)
```
It supports any object and detects the class type of the input content.

#### Add Title
```python
doc.add(
    docflow.Title('Hello', level=3)
)
```
OUTPUT:
> ### Hello
`level`: The title level.

#### Add Catalog
```python
doc = docflow.Document(
    docflow.Catalog(doc),
    doc
)
```
It automatically scans all titles in `doc` and create a catalog.

#### Add Text
```python
doc.add(
    docflow.Text('Hello, **Bold**, `Badge`')
)
```
OUTPUT:
> Hello, **Bold**, `Badge`

#### Add Time Stamp
```python
doc.add(
    docflow.DateTimeStamp(timefmt='%d-%m-%Y %H:%M:%S %Z')
)
```
OUTPUT:
> `25-04-2024 16:01:53 Central Daylight Time`

#### Add Code
##### Auto Get Code from Function
```python
def hello():
    print('Hello World!')
doc.add(
    docflow.Code(hello)
)
```
OUTPUT:
>```python
> def hello():
>    print('Hello World!')
>```

#### Add Identical Badge
```python
doc.add(
    docflow.IdenticalBadge()
)
```
OUTPUT:
>![DocFlow-AutoDoc](https://img.shields.io/badge/DocFlow-AutoDoc-2ea44f)  

#### Add Sequence
```python
a = ['Item 1',
     docflow.DateTimeStamp(),
     docflow.IdenticalBadge()]
doc.add(
    docflow.Sequence(a)
)
```
OUTPUT:
>- Item 1  
>- `25-04-2024 16:07:58 Central Daylight Time`  
>- ![DocFlow-AutoDoc](https://img.shields.io/badge/DocFlow-AutoDoc-2ea44f) 

#### Add Table
```python
import pandas as pd
t = pd.DataFrame([[1,2,3], [4,5,6], [7,8,9]])
doc.add(
    docflow.Table(t)
)
```
OUTPUT:
>|    |   0 |   1 |   2 |
>|---:|----:|----:|----:|
>|  0 |   1 |   2 |   3 |
>|  1 |   4 |   5 |   6 |
>|  2 |   7 |   8 |   9 |  

#### Add Image
**Warning:** This will embeded image to document and increase the size of file sharply!
```python
import matplotlib.pyplot as plt
fig = plt.figure(figsize=(3, 2))
ax = fig.subplots()
ax.plot([1,2,5,7,9])
ax.grid()
doc.add(
    docflow.EmbeddedImage(fig)
)
```
OUTPUT:
><img src="data:image/jpg;base64,/9j/4AAQSkZJRgABAQEAZABkAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wAARCADFAQ8DASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD3+iiigAoorl/GEBvL7w1YtcXcMFzqbJN9luZIGdRazuBuQg43Kp69qAOoorlL7wZpkOn3Msd5rgdImZT/AG5ecED/AK61OPBGlYH+l65/4PLz/wCO0AdJRXOf8IRpX/P1rn/g8vP/AI7R/wAIRpX/AD9a5/4PLz/47QB0dFc5/wAIRpX/AD9a5/4PLz/47R/whGlf8/Wuf+Dy8/8AjtAHR0Vzn/CEaV/z9a5/4PLz/wCO1Wfwbpo1GGIXmubGidiP7cvOoK4/5a+5oA6yiuc/4QjSv+frXP8AweXn/wAdo/4QjSv+frXP/B5ef/HaAOjornP+EI0r/n61z/weXn/x2j/hCNK/5+tc/wDB5ef/AB2gDo6K5z/hCNK/5+tc/wDB5ef/AB2j/hCNK/5+tc/8Hl5/8doA6OiuTsvBumzQMz3muEiWRf8AkOXnQOQP+WvoKs/8IRpX/P1rn/g8vP8A47QB0dFc5/whGlf8/Wuf+Dy8/wDjtH/CEaV/z9a5/wCDy8/+O0AdHRXOf8IRpX/P1rn/AIPLz/47R/whGlf8/Wuf+Dy8/wDjtAHR0Vyd74N02GBWS81wEyxr/wAhy86FwD/y19DVn/hCNK/5+tc/8Hl5/wDHaAOjornP+EI0r/n61z/weXn/AMdo/wCEI0r/AJ+tc/8AB5ef/HaAOjornP8AhCNK/wCfrXP/AAeXn/x2j/hCNK/5+tc/8Hl5/wDHaAOjornP+EI0r/n61z/weXn/AMdqnB4T0ibU7qBNQ1p1hRNyrrt2SjEtkH971wBxQB19FcTe6JBofiPwxJZXmq/6RqDwypPqlxOjp9lnbBWRyPvKp6dq7agAoorK1bxJpWiTRQX08gnlUukUMEkzlR1YrGrEKMjkjFAGrXOeJf8AkPeEf+wq/wD6R3Nblle22pWMN7ZTpPbToHjlQ5DKe9YfiX/kPeEf+wq//pHc0AbOp/8AIKu/+uL/AMjVkdBVbU/+QVd/9cX/AJGrI6CgBaKKKACiiigAqpJ/yF7f/rhJ/wChJVuqkn/IXt/+uEn/AKElAFuiiigAooooAKKKKAKmnf8AHs//AF3l/wDRjVbqpp3/AB7P/wBd5f8A0Y1W6ACiiigAooooAqaj/wAeyf8AXeL/ANGLVuqmo/8AHsn/AF3i/wDRi1boAKKKKACoLy9ttPtXubydIYUHzO5wKxtY8Uw2Nz/Z2nwtqGqt922hP3Pd26KKrWfhefULpNR8TTreXCnMdov+oh+g/iPuf1rVU7LmnovxZjKrd8sNX+C/rsQHUNZ8WEppIfTNJPDX0i4lmH/TMdh7/wD6q1dD0Wy0O6uLayjIBijZ3c5aRsvyx9a2wAAABgDtVSP/AJC9x/1wj/8AQnpSqXXLHRf1uOFOz5pav+tjH8S/8h7wj/2FX/8ASO5ro65zxL/yHvCP/YVf/wBI7mujrM1CvPPF9xFbeOLeS41t/Dsf9mMq6kqqftBMhzDmQFBtwG6bju4Iwc+h0UAc34BDL4G0pXtfsxERATay7gGOHwxLDcMPgnPzVk61pF7beJ/C8sviHUrpJNUkCwzR24WP/Rbg5XbEDwBjkng+vNd1XOeJf+Q94R/7Cr/+kdzQBf1G1mXTbpjfXDARMSpVMHjpwtWBaT4H/Ewuf++Y/wD4mnan/wAgq7/64v8AyNWR0FAFX7HP/wBBC5/75j/+Jo+xz/8AQQuf++Y//iat0UAVPsc//QQuf++Y/wD4mj7HP/0ELn/vmP8A+Jq3RQBU+xz/APQQuf8AvmP/AOJqq9rN/acC/brjJhkO7CZHKcfd/wA4rVqpJ/yF7f8A64Sf+hJQAfY5/wDoIXP/AHzH/wDE0fY5/wDoIXP/AHzH/wDE1booAqfY5/8AoIXP/fMf/wATR9jn/wCghc/98x//ABNW6KAKn2Of/oIXP/fMf/xNH2Of/oIXP/fMf/xNW6KAMqwtZmt2Ivrhf30gwAn99ufu1a+xz/8AQQuf++Y//iaNO/49n/67y/8Aoxqt0AVPsc//AEELn/vmP/4mj7HP/wBBC5/75j/+Jq3RQBU+xz/9BC5/75j/APiaPsc//QQuf++Y/wD4mrdFAGVf2sy26k31w376MYIT++vP3atfY5/+ghc/98x//E0aj/x7J/13i/8ARi1k6v4qitLr+ztNgbUdVbgW8R4j93boo/zxVRg5OyJnOMFeRevXj021e6vNYmghTq7iMfh93k+1c1FNr3ilyNPurqw0c8G6mVRLMP8AYAAIHv8A/qq/ZeFpr26TUvEs6310vMdso/cQewXufc/r1rqQMDA6VpeNPbV/gZWnU+LRfj/wDE0rwzbaLAYrC4nj3HLvhCzn1JK5NaH2Of8A6CFz/wB8x/8AxNW6Kybcndm0YqKsip9jn/6CFz/3zH/8TVVLWb+051+3XGRDGd2EyeX4+7/nNatVI/8AkL3H/XCP/wBCekMwNfgki8Q+Eme6llH9qSDa4XA/0O454Arqq5zxL/yHvCP/AGFX/wDSO5ro6ACiiigArnPEv/Ie8I/9hV//AEjua6Ouc8S/8h7wj/2FX/8ASO5oA2dT/wCQVd/9cX/kasjoKran/wAgq7/64v8AyNWR0FAC0UUUAFFFFABVST/kL2//AFwk/wDQkq3VST/kL2//AFwk/wDQkoAt0UUUAFFFFABRRRQBU07/AI9n/wCu8v8A6MardVNO/wCPZ/8ArvL/AOjGq3QAUUUUAFVr/ULTTLR7q9nSCFerOf0HqfasbVvFUdtdnTdKgbUdUPHkxH5Y/d26D/PSobDwtJdXaal4juBf3g5jgA/cQeyr3Puf/r1qqaS5p6L8TF1W3y09X+CM+8vtY8VQqLOOTTdGaWMG4cYmmy4AKD+Ed8//AKq6jSNEsNDtfIsYBGDy7nl3Pqx71LqP/Hqn/XaL/wBGLVulKo2uVaIcKaT5nqwooorM1CiiigAqpH/yF7j/AK4R/wDoT1bqpH/yF7j/AK4R/wDoT0AY/iX/AJD3hH/sKv8A+kdzXR1zniX/AJD3hH/sKv8A+kdzXR0AFef+Kr7V7/xxB4esILqWCLTvt0iW9+1lvJkKDdKoLcbeFXGS3JwK9ArF1fw3Bqt/BqEd9e6ffRRtCLizdVZo2IJRgysCMgEcZB6EUAP8L6hBqnhqxu7cXIjZChW5ffKrKxVlZsncQykZzziuc1rV7258T+F4pfD2pWqR6pIVmmktysn+i3Awu2UnkHPIHA9eK67StLtdF0u306yQpbwLtUMxYnnJJJ6kkkk+prI8S/8AIe8I/wDYVf8A9I7mgC/qN1M2m3SmxuFBiYFiyYHHXhqsC7nwP+Jfc/8AfUf/AMVTtT/5BV3/ANcX/kasjoKAKv2yf/oH3P8A31H/APFUfbJ/+gfc/wDfUf8A8VVuigCp9sn/AOgfc/8AfUf/AMVR9sn/AOgfc/8AfUf/AMVVuigCp9sn/wCgfc/99R//ABVVXupv7Tgb7DcZEMg25TJ5Tn73+c1q1Uk/5C9v/wBcJP8A0JKAD7ZP/wBA+5/76j/+Ko+2T/8AQPuf++o//iqt0UAVPtk//QPuf++o/wD4qj7ZP/0D7n/vqP8A+Kq3RQBU+2T/APQPuf8AvqP/AOKo+2T/APQPuf8AvqP/AOKq3RQBlWF1MtuwFjcN++kOQU/vtx96rX2yf/oH3P8A31H/APFUad/x7P8A9d5f/RjVj6r4qSG7OmaRbnUtUPBijPyRe7t0H0/lVRg5uyJnOMFdl6/12LS7Rrq+tpoIV6s7x8+wG7k+wrnZr7XvFQUWVtdado79ZhtE8w/2QSNoPr/PpWhp/hV57tdT8RXA1C+HKRY/cweyr3+p/wDr109ac0afw6vv0+RlyzqfFou3X5mLpNjb6JaC3sNHnjXqzboyzn1Y7uTV/wC2T/8AQPuf++o//iqt0Vk227s2SUVZGVf3UzW6g2Nwv76M5JT++vH3qtfbJ/8AoH3P/fUf/wAVRqP/AB7J/wBd4v8A0YtW6Qyp9sn/AOgfc/8AfUf/AMVR9sn/AOgfc/8AfUf/AMVVuigCp9sn/wCgfc/99R//ABVH2yf/AKB9z/31H/8AFVbooAqfbJ/+gfc/99R//FVVS6m/tOdvsNxkwxjblMjl+fvf5xWrVSP/AJC9x/1wj/8AQnoAwNfnkl8Q+Ele1liH9qSHc5XB/wBDuOOCa6quc8S/8h7wj/2FX/8ASO5ro6ACiiigArnPEv8AyHvCP/YVf/0jua6Ouc8S/wDIe8I/9hV//SO5oA2dT/5BV3/1xf8AkasjoKran/yCrv8A64v/ACNWR0FAC0UUUAFFFFABVST/AJC9v/1wk/8AQkq3VST/AJC9v/1wk/8AQkoAt0UUUAFFFFABUF5eW9haSXV1KsUEY3O7dAKLy8t9PtJbu7lWKCIbmdu1cpaWdz4yvI9S1OJodGibdaWTdZj2kkHp6D+nXSEL+9LYznUt7sdWyCybWvFcDLbO+l6K8kjecP8AXzgsTgf3RzjP8+ldXpWj2Gi2gtrC3WJOrHqzn1J6k07TQBasAMATS/8AoxquUTqNrlWiCFNRfM9X3CiiiszQKKKKAKmo/wDHsn/XeL/0YtW6qaj/AMeyf9d4v/Ri1boAKKKKACiiigAqpH/yF7j/AK4R/wDoT1bqpH/yF7j/AK4R/wDoT0AY/iX/AJD3hH/sKv8A+kdzXR1zniX/AJD3hH/sKv8A+kdzXR0AFZ+s6rFo+nNcvG00jMI4IE+9NK3CovuT37DJPANaFYOueHJdY1Kxv4NZvdPms1cR+RHE65fALYkRhuwMZHOCR3NAFjwxrTeIvDllqzWwtmuULGESb9hBIxuwM9PQVQ8SMp17wjhh/wAhV+//AE53NN+H2jajoPg6zsNUmle6QsSknl/ugT90FBgjvk5PzHnoBm614Y0Cw8T+F7mz0TTreebVJFlkitkVnBtLhiGIGTyAfqKAOu1Mj+yrvn/li/8AI1aBGByKzNR06yj026dLSBWWJiCIwCDirI0ywwP9Ct/+/QoAtZHqKMj1FVv7MsP+fK3/AO/Qo/syw/58rf8A79CgCzkeooyPUVW/syw/58rf/v0KP7MsP+fK3/79CgCzkeoqpIR/a1vz/wAsJP5pTv7MsP8Anyt/+/QqrJp1kNUgQWkG0wyEjyxgkFMfzNAGnkeooyPUVW/syw/58rf/AL9Cj+zLD/nyt/8Av0KALOR6ioL2+ttPs5bu6mWKCMZZ2PSqt7Do+nWct3d29rFBEMs7Rj/DrXM6bow8U3yatf2SW2lRnNpZ7Apl/wBuTHb0H9OukIX96WxlOdvdjq3/AFqS2dpceMbyPU9UjaHR4m3Wdk/WY9pJB6eg/p17IEAYGAKq/wBl2H/Plb/9+h/hS/2ZYf8APlb/APfoUpz5vQcIcvm2N04j7M/P/LeX/wBGNVvI9RWZYadZPbsWtIGPnSjJjB4DsBVr+zLD/nyt/wDv0Kg0LOR6ijI9RVb+zLD/AJ8rf/v0KP7MsP8Anyt/+/QoAs5HqKMj1FVv7MsP+fK3/wC/Qo/syw/58rf/AL9CgBuokfZk5/5bxf8Aoxat5HqKzL/TrJLdStpAp86IZEYHBdQatf2ZYf8APlb/APfoUAWcj1FGR6iq39mWH/Plb/8AfoUf2ZYf8+Vv/wB+hQBZyPUUZHqKrf2ZYf8APlb/APfoUf2ZYf8APlb/APfoUAWcj1FVIyP7WuOf+WEf83p39mWH/Plb/wDfoVVj06yOqTobSDaIYyB5YwCS+f5CgDP8SEf294R5/wCYq/8A6R3NdJXK6/Z21v4g8JPDbxRsdUkBKIAcfY7iuqoAKKKKACuc8S/8h7wj/wBhV/8A0jua6Ouc8S/8h7wj/wBhV/8A0juaANnU/wDkFXf/AFxf+RqyOgqtqf8AyCrv/ri/8jVkdBQAtFFFABRRRQAVUk/5C9v/ANcJP/Qkq3VST/kL2/8A1wk/9CSgC3Ve+vrbTbOW7u5VigiGWZv88n2ovr6202ylu7uVYoIxlmP+eT7Vy1lY3Pi69j1bVomi0qI7rKxf/lp6SSD+Q/p10hC65pbGU5tPljq3/V2JZWVz4vvY9V1WJotJiO6zsX/5aekkg/kP6dey6UUUpz5vQqEFDzbCiiioLKmnf8ez/wDXeX/0Y1W6qad/x7P/ANd5f/RjVboAKKKKACiiigCpqP8Ax7J/13i/9GLVuqmo/wDHsn/XeL/0YtW6ACiiigAooooAKqR/8he4/wCuEf8A6E9W6qR/8he4/wCuEf8A6E9AGP4l/wCQ94R/7Cr/APpHc10dc54l/wCQ94R/7Cr/APpHc10dABVC/wBc0jSpY4tR1Wxs5JP9WlxcJGX+gYjNX65jxTf2lvIthbWFrfa7qEJihhlQECPnLynHESlj9ScDk0AdMCGAIIIPIIrnfEv/ACHvCP8A2FX/APSO5rS0DSxonh3TdLWdpxZ20cHmt1faoGf0rltat/ECeJ/C7Xmp6bLAdUk8pIbB42U/ZbjG5jMwbjI4A5OfagDsNT/5BV3/ANcX/kasjoKzNRjvhpt0XuLcr5TZAhIJGPXdVgR6hgf6Tbf9+G/+LoAuUVU8vUP+fm2/78N/8XR5eof8/Nt/34b/AOLoAt0VU8vUP+fm2/78N/8AF1l6nr9vo4IvtZsI3H/LMQsz/wDfIfNOMXJ2SFKSirydjfrL1O/ttMukvLyVYoI7eUsx/wB5OPc+1c/H4k8RakwGj6R5kR/5eLuIwJ9QCxJH0pG8OarqWs2c2vX9rcGNXkjto4T5KEFevILde/pWqpcus3b8/wCvUydVy0pq/wCX9ehJY2F14tvY9W1eJotMiO6ysX/j9JJB39h/Tr2NVPL1D/n5tv8Avw3/AMXR5eof8/Nt/wB+G/8Ai6ic+Z+RcKagvNluiqnl6h/z823/AH4b/wCLo8vUP+fm2/78N/8AF1BZboqp5eof8/Nt/wB+G/8Ai6PL1D/n5tv+/Df/ABdABp3/AB7P/wBd5f8A0Y1W6yrCO+Nu2y4twPOk6wk872z/ABVa8vUP+fm2/wC/Df8AxdAFuiqnl6h/z823/fhv/i6PL1D/AJ+bb/vw3/xdAFuiqnl6h/z823/fhv8A4ujy9Q/5+bb/AL8N/wDF0AGo/wDHsn/XeL/0YtW6yr+O+Fuu+4tyPOj6Qkc71x/FVry9Q/5+bb/vw3/xdAFuiqnl6h/z823/AH4b/wCLo8vUP+fm2/78N/8AF0AW6KqeXqH/AD823/fhv/i6PL1D/n5tv+/Df/F0AW6qR/8AIXuP+uEf/oT0eXqH/Pzbf9+G/wDi6qpHff2nOBcW+7yY8nyTjGXxxu+tAFHxL/yHvCP/AGFX/wDSO5ro65XX0ul8Q+EjPNE6/wBqSYCRFTn7HcerGuqoAKy9S8NaDrNwtxqmiabfTqgRZLq1SVguScAsCcZJOPc1qUUARWtrb2VrHa2kEVvbxLtjiiQIiD0AHAFYPiX/AJD3hH/sKv8A+kdzXR1zniX/AJD3hH/sKv8A+kdzQBs6n/yCrv8A64v/ACNWR0FZ+vm5XQb02axtP5RwJCQuO/T2zWKPDWs6mAdb1+byz1trAeUn0LdSPrVxgmrt2M5TadkrmtqfiXR9IyL3UIY3H/LMHc//AHyMmsn/AISbV9T40PQJih6XN8fKT6herD6Vq6Z4Z0bSMGz0+FJB/wAtWG5/++jk1rVfNTjsr+v+S/zJ5akt3b0/zf8Akcp/wjet6pzrevyrGettp48pfpu6kfWtTTPDGjaQQ1np8SyD/lq43v8A99HJrXoqZVZtWvoONGCd7XfnqFVJP+Qvb/8AXCT/ANCSrdVJP+Qvb/8AXCT/ANCSszUt0UUUAFFFFABRRRQBU07/AI9n/wCu8v8A6MardVNO/wCPZ/8ArvL/AOjGq3QAUUUUAFFFFAFTUf8Aj2T/AK7xf+jFq3VTUf8Aj2T/AK7xf+jFq3QAUUUUAFFFFABVSP8A5C9x/wBcI/8A0J6t1Uj/AOQvcf8AXCP/ANCegDH8S/8AIe8I/wDYVf8A9I7mujrnPEv/ACHvCP8A2FX/APSO5ro6ACiiigArE8RaPfaq+lz6de29pc6fdm5Rri3MyNmKSMgqHQ9JCevatuigDh/EzeMdL8LatqD6zokyWtnLM0Y0qVS4VCcZ+0HGcdcGtRbPxmVB/t7Q+R/0B5f/AJJrdvZrSCymkv5IY7QKfNadgEC99xPGPrSWV9Z6lapdWF1BdW7/AHZYJA6N9COKAMT7F4z/AOg9of8A4J5f/kmj7F4z/wCg9of/AIJ5f/kmujooA5z7F4z/AOg9of8A4J5f/kmj7F4z/wCg9of/AIJ5f/kmujooA5z7F4z/AOg9of8A4J5f/kmsm4bxjH4s0/TjrGiF57K5mEn9lS4UI8IIx9o5z5g5zxjvnjuaoLqeky6v9hW+sn1OND+4EqGZV4z8udwH3c/hQBl/YvGf/Qe0P/wTy/8AyTR9i8Z/9B7Q/wDwTy//ACTXR0UAc59i8Z/9B7Q//BPL/wDJNH2Lxn/0HtD/APBPL/8AJNdHRQBzn2Lxn/0HtD/8E8v/AMk0fYvGf/Qe0P8A8E8v/wAk10dVr7ULLTLY3OoXlvaQA4MtxKsag/UkCgDj/DreMdS02adNY0SILe3UO06VK2THPIhOftA6lc47Zxz1rW+xeM/+g9of/gnl/wDkmtqwubG7tFuNOmt5raQllkt3VkYk5JBXg85zVmgDnPsXjP8A6D2h/wDgnl/+SaPsXjP/AKD2h/8Agnl/+Sa6OigDnPsXjP8A6D2h/wDgnl/+SaPsXjP/AKD2h/8Agnl/+Sa6OigDhvETeMdN02Gd9Y0SUNe2sO0aVKuDJPGgOftB6Fs474xx1rW+xeM/+g9of/gnl/8AkmtC91vQ7e9TT77VNOiunZSltPcIrk5ypCk5znBFadAHOfYvGf8A0HtD/wDBPL/8k0fYvGf/AEHtD/8ABPL/APJNdHRQBzn2Lxn/ANB7Q/8AwTy//JNH2Lxn/wBB7Q//AATy/wDyTXR0UAc59i8Z/wDQe0P/AME8v/yTWTbt4xk8Wahpw1jRA8FlbTGT+ypcMHeYAY+0cY8s855z2xz3NVWu7CLU0tXuLZL+ePKRF1EsiLnkDqQMn6ZoAwRoXiG71jSrvVdZ02aDT7hrgRW2nPEzsYpI8bmmcYxIT07V1FFFABRRRQAUUUUAcl468rf4b+17f7P/ALZi+07/ALmPLk8vdnjHmeX174pPC3k/8Jh4u+xbPsP2i3/1X3PP8oeZjHGceXn36811Nza297bSW11BFPBINrxSoGVh6EHg0yysLPTbVLWwtILW3T7sUEYRF+gHFAFiiiigAooooAK43U1s7f4oeHnjEEcj2V+ZSoALNm3xu9T9a7Ksi58KeHL2+a+utA0qe7ZgzTy2cbSEjoSxGc8D8qANeiiigAooooAKy9fv9L0vTft2rIjxwyAwoYw7tKchVjXqXOSBjnk+9alU9S0nTdZt1t9U0+0voFcOsd1CsqhsEZAYEZwSM+5oAx/B+l3Flb6jfXcUVtcapdm7e0hIK2+UVQuRwWwgLEcFifrXSVS03RtL0aJ4tK02zsY3bc6WsCxBj6kKBk1doAKKKKACiiigDiPiNG03hjVvs93pEUC2zi/S5jBlddoICPnCNt6FlbkqcV12myLNpdpKiSIjwoypL99QVHDe/rVa48P6Ld6guoXOj6fNerjFzJbI0gx0+YjPFaVABRRRQAUUUUANkYrGzKpdgCQo6n2ryWyudSX4g+Hb3VPDuqRapeNc/aHcwFFUqoVUIlJ8uMHJyATlmAJYivXKie1t5biK4kgieeEMIpGQFk3ddp6jOBnHWgCWiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAP/9k=">
