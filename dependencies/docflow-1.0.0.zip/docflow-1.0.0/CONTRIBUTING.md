# Contributing to [DocFlow](https://git.tulane.edu/jrestool/docflow)

Thank you for your interest in contributing to [DocFlow](https://git.tulane.edu/jrestool/docflow)! We appreciate your help in making this project better.

## Table of Contents
1. [How to Contribute](#how-to-contribute)
   - [Reporting Bugs](#reporting-bugs)
   - [Suggesting Enhancements](#suggesting-enhancements)
   - [Pull Requests](#pull-requests)
2. [Development Workflow](#development-workflow)
3. [Style Guides](#style-guides)
   - [Code Style](#code-style)
   - [Commit Messages](#commit-messages)
4. [License](#license)

## How to Contribute

### Reporting Bugs

If you find a bug, please create an issue on GitHub with the following details:
- **Description:** A clear and concise description of the bug.
- **Steps to Reproduce:** Detailed steps to reproduce the bug.
- **Expected Behavior:** What you expected to happen.
- **Actual Behavior:** What actually happened.
- **Screenshots:** If applicable, add screenshots to help explain the issue.

### Suggesting Enhancements

To suggest an enhancement, please create an issue on GitHub with the following details:
- **Description:** A clear and concise description of the enhancement.
- **Use Case:** Explain why this feature would be useful.

### Pull Requests

To contribute code, follow these steps:
1. Fork the repository.
2. Create a new branch (`git checkout -b feature/your-feature-name`).
3. Commit your changes (`git commit -am 'Add new feature'`).
4. Push to the branch (`git push origin feature/your-feature-name`).
5. Open a Pull Request on GitHub.

Ensure your pull request adheres to the following guidelines:
- Describe the purpose and motivation of the pull request.
- Reference any relevant issues or related pull requests.
- Add relevant tests if applicable.

## Development Workflow

1. Clone the repository and set up the development environment.
2. Run tests to ensure your changes don't break existing functionality.
3. Commit and push your changes following the style guide.
4. Open a Pull Request and wait for review.

## Style Guides

### Code Style

Please follow the project's coding conventions. This includes proper indentation, naming conventions, and code organization. Refer to the existing codebase for examples.

### Commit Messages

- Use the present tense ("Add feature" not "Added feature").
- Use the imperative mood ("Move cursor to..." not "Moves cursor to...").
- Keep messages concise but informative.

## License

By contributing to [DocFlow](https://git.tulane.edu/jrestool/docflow), you agree that your contributions will be licensed under the [Apache License 2.0](LICENSE).

---

Thank you for contributing to [DocFlow](https://git.tulane.edu/jrestool/docflow)!
