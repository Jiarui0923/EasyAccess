"""Package installer."""
from setuptools import find_packages, setup

LONG_DESCRIPTION = '''
This module imports various components used to build markdown documentation in the DocFlow project.
The components include different document types such as text, code, images, tables, and badges, 
as well as utilities like timestamps, expanders, and catalogs. The imported classes and functions 
are used to create and manage different types of markdown documentation structures.

This package is maintained by Jiarui LI. If there is any bug and question, please feel free to send Email to jli78@tulane.edu or post an issue.
'''

setup(
    name='DocFlow',
    version='1.0.0',
    description='Documentation Generation Tool',
    long_description=LONG_DESCRIPTION,
    long_description_content_type="text/markdown",
    author='Jiarui Li',
    author_email=('jli78@tulane.edu'),
    url='https://git.tulane.edu/jrestool/docflow',
    license='Apache 2.0',
    install_requires=[
        'pandas', 'matplotlib', 'markdown', 'tabulate'
    ],
    classifiers=[
        'Intended Audience :: Developers',
        'Intended Audience :: Science/Research',
        'License :: OSI Approved :: Apache 2.0 License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.8',
        'Topic :: Software Development :: Libraries :: Python Modules'
    ],
    packages=find_packages('.'),
    package_data={
        'docflow.property': ['github-markdown.css'],
    },
)
