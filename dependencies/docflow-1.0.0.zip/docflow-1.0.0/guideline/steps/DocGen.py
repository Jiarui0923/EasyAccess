import io
import os
import base64
import matplotlib
import inspect
from datetime import datetime
import pandas as pd

class Document:
    
    def __init__(self, *args):
        self._documents = args
    
    def _tab_append(self, obj):
        lines = obj.split('\n')
        return f'{lines[0]}\n' + ''.join([f'\t{i}\n' for i in lines[1:]])
    
    @property    
    def markdown(self):
        return ''.join([d.markdown for d in self._documents])
    
    def __repr__(self):
        return self.markdown
    
    def __call__(self, tab=False):
        if tab:
            return self._tab_append(self.markdown)
        else:
            return self.markdown
    
    def add(self, doc):
        if isinstance(doc, Document):
            self._documents.append(doc)
            
    def render(self):
        try:
            from IPython import get_ipython
            from IPython.display import display, Markdown
            get_ipython()
            display(Markdown(self.markdown))
        except:
            print(self.markdown)
            
    def save(self, path):
        with open(path, 'w') as f:
            f.write(self.markdown)

class Title(Document):
    
    def __init__(self, context='', level=1):
        if level < 1 or level > 5:
            raise ValueError(f'Title level can be 1~5. {level} is not valid')
        self._level = level
        self._context = context
    
    @property   
    def markdown(self):
        return f'{"".join(["#" for _ in range(self._level)])} {self._context}  \n'
    
    
class Text(Document):
    
    def __init__(self, text):
        self._text = text
        
    @property   
    def markdown(self):
        return f'{self._text}  \n'

class DateTimeStamp(Document):
    
    def __init__(self, timefmt='%d-%m-%Y %H:%M:%S', text=None):
        self._timefmt = timefmt
        self._text = text
    
    @property   
    def markdown(self):
        _time = datetime.now().strftime(self._timefmt)
        if self._text is None:
            return f'`{_time}`  \n'
        else:
            return f'`{_time} {self._text}`  \n'
        
class Sequence(Document):
    
    def __init__(self, seq, num_index=False):
        self._seq = seq
        self._num_index = num_index
    
    @property     
    def markdown(self):
        if isinstance(self._seq, list):
            items = [f'{i(tab=True)}' if isinstance(i, Document) else f'{i}'
                     for i in self._seq]
        elif isinstance(self._seq, dict):
            items = [f'**{i}**: {v(tab=True)}' if isinstance(v, Document) else f'**{i}**: {v}'
                     for i, v in self._seq.items()]
        else:
            raise TypeError

        if self._num_index:
            return ''.join([f'{index} {i}  \n' for index, i in enumerate(items)])
        else:
            return ''.join([f'- {i}  \n' for i in items])
        
class Table(Document):
    
    def __init__(self, df):
        if not isinstance(df, pd.DataFrame):
            raise TypeError
        self._df = df
    
    @property    
    def markdown(self):
        return f'{self._df.to_markdown()}  \n\n'
    
class Code(Document):
    
    def __init__(self, obj, lang=''):
        if inspect.isfunction(obj):
            self._lang = 'python'
            self._obj = inspect.getsource(obj)
        elif isinstance(obj, str):
            self._lang = lang
            self._obj = obj
        else:
            raise TypeError
    
    @property     
    def markdown(self):
        return f'```{self._lang}\n {self._obj}```\n'
    
class EmbeddedImage(Document):
    
    def __init__(self, image, title=None):
        if isinstance(image, matplotlib.figure.Figure):
            img_stream = io.BytesIO()
            image.savefig(img_stream, format='jpg', bbox_inches='tight')
            img_stream.seek(0)
            img_base64 = base64.b64encode(img_stream.read()).decode()
            self._image_base64 = f'<img src="data:image/jpg;base64,{img_base64}">'
            image.clear()
        elif os.path.isfile(image):
            with open(image, 'rb') as f:
                img_stream = io.BytesIO(f.read())
                img_stream.seek(0)
                img_base64 = base64.b64encode(img_stream.read()).decode()
                self._image_base64 = f'<img src="data:image/jpg;base64,{img_base64}">'
        else:
            raise TypeError
    
    @property     
    def markdown(self):
        return f'{self._image_base64}   \n\n'
    
class IdenticalBadge(Document):
    
    def __init__(self):
        
        self._badge = '![Auto - Doc](https://img.shields.io/badge/Auto-Doc-2ea44f)'
    
    @property  
    def markdown(self):
        return f'{self._badge}  \n\n'