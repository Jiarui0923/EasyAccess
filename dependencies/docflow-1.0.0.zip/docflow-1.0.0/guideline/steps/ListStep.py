from . import DocGen as doc
import platform

class ListStep:
    
    name = 'EMPTY'
    
    @property
    def _guideline(self):
        return doc.Text('_TBD_')
    
    @property
    def _windows_guideline(self):
        return self._guideline
    
    @property
    def _macos_guideline(self):
        return self._guideline
    
    @property
    def _linux_guideline(self):
        return self._guideline
    
    @property
    def _os_type(self):
        return platform.system()
    
    @property
    def guideline(self):
        if   self._os_type == 'Linux':   return self._linux_guideline
        elif self._os_type == 'Windows': return self._windows_guideline
        elif self._os_type == 'Darwin':  return self._macos_guideline
        else: raise EnvironmentError(f'{self._os_type} Not Support.')
    
    @property
    def is_done(self):
        return False
        
    @property
    def note(self):
        return ''