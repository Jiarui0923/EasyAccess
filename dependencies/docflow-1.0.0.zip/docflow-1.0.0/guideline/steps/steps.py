from .ListStep import ListStep
from . import DocGen as doc
import os
import platform
import pandas as pd

class StepCondaSetup(ListStep):
    
    name = 'CONDA Setup'
    
    def _conda_version(self):
        conda_info = os.popen("conda --version").read()
        if len(conda_info) < 1: return None
        conda_info = conda_info.split(' ')[-1][:-1]
        return conda_info
    
    @property
    def is_done(self):
        if self._conda_version() is None:
            return False
        else:
            return True
    
    @property
    def _guideline(self):
        return doc.Text('Please following this link to download and install conda: [https://repo.anaconda.com/miniconda/Miniconda3-latest-Windows-x86_64.exe](https://repo.anaconda.com/miniconda/Miniconda3-latest-Windows-x86_64.exe)')
    
    @property
    def note(self):
        return f'Version: {self._conda_version()}'
    
class StepCondaEnvCreate(ListStep):
    
    name = 'CONDA Environment Create'
    
    def _conda_env_name(self):
        return os.environ.get('CONDA_DEFAULT_ENV')
    
    @property
    def is_done(self):
        if self._conda_env_name() == 'base':
            return False
        else:
            return True
    
    @property
    def _guideline(self):
        return doc.Text('Please create conda environment following: `conda create -n docflow python=3.8` and activate it with `conda activate docflow` (The name can be changed to your prefer one.). If you have already activated it, please directly activate it.')
    
    @property
    def note(self):
        return f'Env: {self._conda_env_name()}'
    
class StepPythonSetup(ListStep):
    
    name = 'Python Setup'
    
    def _python_version(self):
        return platform.python_version_tuple()
    
    @property
    def is_done(self):
        _p_v = self._python_version()
        if int(_p_v[0]) != 3 and int(_p_v[1]) < 6:
            return False
        else:
            return True
    
    @property
    def _guideline(self):
        return doc.Text('Please install python with version greater than `3.6` following instruction: `conda install python=3.8`')
    
    @property
    def note(self):
        _p_v = self._python_version()
        return f'Python: {_p_v[0]}.{_p_v[1]}.{_p_v[2]}'
    
class StepNvidiaSetup(ListStep):
    
    name = 'NVIDIA Driver & CUDA'
    
    def _cuda_version(self):
        r_ = os.popen("nvidia-smi").read()
        if len(r_) < 1: return None
        tokens = r_.split(' ')
        cuda_pos = tokens.index('CUDA')
        _cuda_version = tokens[cuda_pos + 2]
        return _cuda_version
    
    @property
    def is_done(self):
        if self._cuda_version() is None:
            return False
        else:
            return True
    
    @property
    def _windows_guideline(self):
        return doc.Text('`WINDOWS` Version  \nFollowing official instructions. [https://www.nvidia.com/Download/index.aspx?lang=en-us](https://www.nvidia.com/Download/index.aspx?lang=en-us)\n')
    
    @property
    def _macos_guideline(self):
        return doc.Text('`MACOS` Version  \nFollowing official instructions. [https://www.nvidia.com/en-us/drivers/cuda/mac-driver-archive/](https://www.nvidia.com/en-us/drivers/cuda/mac-driver-archive/)\n')
    
    @property
    def _linux_guideline(self):
        return doc.Text('`LINUX` Version  \nPlease install CUDA following: \n```bash\n sudo apt update\nsudo apt install build-essential\nsudo apt install nvidia-driver-535\n```')
    
    @property
    def note(self):
        return f'CUDA: {self._cuda_version()}'
    
class StepPyTorchSetup(ListStep):
    
    name = 'PyTorch Setup'
    
    def _pytorch_version(self):
        try:
            import torch
            return torch.__version__
        except:
            return None
    
    @property
    def is_done(self):
        if self._pytorch_version() is None:
            return False
        else:
            return True
    
    @property
    def _guideline(self):
        return doc.Text('Please install python with version greater than `3.6` following instruction: `conda install python=3.8`')
    
    @property
    def note(self):
        return f'PyTorch: {self._pytorch_version()}'
    
class StepPackagesSetup(ListStep):
    
    name = 'Other Python Packages Setup'
    
    def __init__(self, packages):
        self.packages = packages
    
    def _pypackage_versions(self, packs):
        versions = {}
        full_install = True
        for pack in packs:
            try:
                _p = __import__(pack)
                versions[pack] = _p.__version__
            except:
                full_install = False
                versions[pack] = None
        return versions, full_install
    
    @property
    def is_done(self):
        _, full_install = self._pypackage_versions(self.packages)
        if not full_install:
            return False
        else:
            return True
    
    @property
    def _guideline(self):
        versions, _ = self._pypackage_versions(self.packages)
        _table = {}
        for pack in self.packages:
            _table[pack] = {
                'Version': versions[pack],
                'Installed': f'{"✅" if versions[pack] is not None else "🔳"}',
                'Install Command': f'`pip install {pack}`'
            }
        df = pd.DataFrame(_table)
        return doc.Document(
            doc.Text('Please check the following table and install the requried packages:'),
            doc.Table(df.T)
        )
    
    @property
    def note(self):
        return ''
    

    