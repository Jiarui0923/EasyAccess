from .guideline import Guideline
from .steps import *


install_guide = Guideline(StepCondaSetup(),
                          StepCondaEnvCreate(),
                          StepPythonSetup(),
                          StepPackagesSetup(['pandas', 'matplotlib', 'markdown', 'tabulate']),
                          name='DocFlow Package Install Guideline')