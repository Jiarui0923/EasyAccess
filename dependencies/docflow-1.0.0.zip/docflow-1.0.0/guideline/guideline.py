from .steps import DocGen as doc

class Guideline:
    
    def __init__(self, *args, name='Installation Guideline'):
        self.name = name
        self._steps = args

    def __call__(self, full_guideline=False): self.render(full_guideline=full_guideline)
    
    def _get_table(self):
        status_list, _guideline = [], None
        for i, step in enumerate(self._steps):
            status_list.append([i + 1, step.is_done, step.name, step.note])
            if _guideline is None and not step.is_done:
                _guideline = step.guideline
        return status_list, _guideline
    
    def _format_guideline(self):
        
        guide_list_doc = []
        status_list, _guideline_step = self._get_table()
        for i, done, name, note in status_list:
            if len(note) > 0:
                guide_list_doc.append(f'{"✅" if done else "🔳"}**STEP {i}**: {name} ({note})')
            else:
                guide_list_doc.append(f'{"✅" if done else "🔳"}**STEP {i}**: {name}')
            
        if _guideline_step is None:
            _current_step = '⌛ All Steps Were Done!'
            _step_inst = doc.Text('')
        else:
            _current_step = '⏳ Current Step'
            _step_inst = _guideline_step
            
        _guideline = doc.Document(
            doc.Title(self.name, level = 3),
            doc.Sequence(guide_list_doc),
            doc.Title(_current_step, level = 4),
            _step_inst
        )
        return _guideline
    
    def _format_full_guideline(self):
        
        docs_list = [doc.Title(self.name, level = 3)]
        for i, step in enumerate(self._steps):
            docs_list.append(doc.Title(f'{"✅" if step.is_done else "🔳"}STEP {i + 1}: {step.name}',
                                       level = 4))
            if len(step.note) > 0:
                docs_list.append(doc.Text(f'({step.note})'))
            docs_list.append(step.guideline)
        return doc.Document(*docs_list)
            

    def render(self, full_guideline=False):
        try:
            from IPython import get_ipython
            from IPython.display import display, Markdown
            if get_ipython() is None: raise Exception
            if full_guideline:
                display(Markdown(self._format_full_guideline().markdown))
            else:
                display(Markdown(self._format_guideline().markdown))
        except:
            if full_guideline:
                print(self._format_full_guideline())
            else:
                print(self._format_guideline())